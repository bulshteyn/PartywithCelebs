"""Zero-dependency static site builder. Run: python3 build.py"""
from pathlib import Path
from html import escape
from datetime import date
import re, shutil
ROOT=Path(__file__).parent
OUT=ROOT/'public'
OUT.mkdir(exist_ok=True)
BASE='https://partywithcelebs.com'
CSS='''*{box-sizing:border-box}body{margin:0;background:#0d0d14;color:#f6f1e9;font:17px/1.7 system-ui,-apple-system,Arial,sans-serif}a{color:#dfc28b}header{border-bottom:1px solid #39313b;padding:20px max(22px,calc((100% - 1100px)/2));display:flex;justify-content:space-between;gap:20px;align-items:center;flex-wrap:wrap}header a{text-decoration:none}nav{display:flex;gap:20px;flex-wrap:wrap;font-size:14px}.brand{font-size:22px;font-weight:900;letter-spacing:.04em;color:white}.brand span{color:#dfc28b}main{max-width:1100px;margin:auto;padding:50px 22px;min-height:65vh}.hero{padding:85px 0 60px;background:radial-gradient(ellipse at 70% 10%,#50334d,transparent 65%)}h1{font-size:clamp(35px,5vw,65px);line-height:1.13;max-width:850px}h2{font-size:30px;line-height:1.3}h3{font-size:22px}p,li{color:#cfc8ca}.eyebrow,.tag{color:#dfc28b;text-transform:uppercase;font-size:12px;letter-spacing:2px;font-weight:700}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:20px}.card{border:1px solid #3a3340;background:#1b1821;border-radius:12px;padding:25px}.card h3{margin:8px 0}.card a{font-weight:700}.button{display:inline-block;background:#dfc28b;color:#151018;text-decoration:none;padding:12px 22px;border-radius:5px;font-weight:700}.article{max-width:760px}.article h1{font-size:clamp(32px,4vw,50px)}.article p,.article li{font-size:18px}.article a{overflow-wrap:anywhere}.meta{font-size:13px;color:#bdb0b7}.notice{font-size:13px;color:#bdb0b7}footer{padding:35px 22px;border-top:1px solid #39313b;text-align:center;font-size:13px;color:#bdb0b7}footer a{margin:0 8px}section{margin-bottom:55px}@media(max-width:600px){main{padding:30px 18px}.hero{padding:45px 0}header{padding:20px}}'''
def inline(s):
    s=escape(s)
    s=re.sub(r'\*\*(.+?)\*\*',r'<strong>\1</strong>',s)
    s=re.sub(r'\[([^\]]+)\]\((https?://[^)]+)\)',lambda m:f'<a href="{m.group(2)}" rel="noopener noreferrer">{m.group(1)}</a>',s)
    return s
def markdown(s):
    result=[]; in_list=False
    for line in s.splitlines():
        line=line.strip()
        if line.startswith('- '):
            if not in_list:result.append('<ul>');in_list=True
            result.append('<li>'+inline(line[2:])+'</li>');continue
        if in_list:result.append('</ul>');in_list=False
        if not line:continue
        if line.startswith('### '):result.append('<h3>'+inline(line[4:])+'</h3>')
        elif line.startswith('## '):result.append('<h2>'+inline(line[3:])+'</h2>')
        else:result.append('<p>'+inline(line)+'</p>')
    if in_list:result.append('</ul>')
    return '\n'.join(result)
def page(title,description,body,path='/',type_='website'):
    canonical=BASE+path
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{escape(title)} | Party With Celebs</title><meta name="description" content="{escape(description,quote=True)}"><link rel="canonical" href="{canonical}"><meta property="og:type" content="{type_}"><meta property="og:title" content="{escape(title,quote=True)}"><meta property="og:description" content="{escape(description,quote=True)}"><meta property="og:url" content="{canonical}"><style>{CSS}</style></head><body><header><a class="brand" href="/">PARTY<span>WITH</span>CELEBS</a><nav><a href="/guides/">Guides</a><a href="/about/">About</a><a href="/contact/">Contact</a></nav></header><main>{body}</main><footer>© {date.today().year} PartyWithCelebs.com · Independent entertainment publication · <a href="/privacy/">Privacy</a><a href="/contact/">Contact</a><p class="notice">Not affiliated with or endorsed by any celebrity, venue, or event organizer unless explicitly stated. Celebrity appearances and access are never guaranteed.</p></footer></body></html>'''
def write(path,html):
    f=OUT/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(html,encoding='utf-8')
def parse(p):
    raw=p.read_text(encoding='utf-8');head,sep,body=raw.partition('\n---\n')
    if not sep:raise ValueError(f'{p}: missing --- separator')
    meta={}
    for line in head.splitlines():
        if ':' in line:
            k,v=line.split(':',1);meta[k.strip()]=v.strip()
    for key in ['title','description','date','category']:
        if not meta.get(key):raise ValueError(f'{p}: missing {key}')
    date.fromisoformat(meta['date'])
    return meta,body
articles=[]
for f in sorted((ROOT/'content').glob('*.md')):
    meta,body=parse(f);slug=f.stem
    articles.append((slug,meta))
    article=f'''<article class="article"><div class="eyebrow">{escape(meta['category'])}</div><h1>{escape(meta['title'])}</h1><p class="meta">Published {escape(meta['date'])} · Editorial guide</p><p><strong>{escape(meta['description'])}</strong></p>{markdown(body)}<p class="notice">Information can change. Verify current prices, entry requirements, and event details with official organizers before booking.</p></article>'''
    write(Path('guides')/slug/'index.html',page(meta['title'],meta['description'],article,f'/guides/{slug}/','article'))
articles.sort(key=lambda x:x[1]['date'],reverse=True)
cards=''.join(f'''<article class="card"><div class="tag">{escape(m['category'])}</div><h3><a href="/guides/{slug}/">{escape(m['title'])}</a></h3><p>{escape(m['description'])}</p><div class="meta">{escape(m['date'])}</div></article>''' for slug,m in articles)
write(Path('index.html'),page('Celebrity Nightlife & VIP Experiences','Independent guides to nightlife, VIP experiences and celebrity event announcements.','''<section class="hero"><div class="eyebrow">The VIP side of entertainment</div><h1>Where nightlife meets the spotlight.</h1><p>Practical guides to VIP nightlife, event planning, and the cities that know how to party.</p><a class="button" href="/guides/">Explore the guides</a></section><section><h2>Featured guides</h2><div class="grid">'''+cards+'''</div></section><section class="card"><h2>For partnerships or acquisition inquiries</h2><p>Reach our editorial team about collaborations, sponsorships, or purchasing PartyWithCelebs.com.</p><a href="/contact/">Get in touch</a></section>'''))
write(Path('guides/index.html'),page('All Guides','Explore all published Party With Celebs nightlife and VIP experience guides.','<h1>Nightlife & VIP Guides</h1><div class="grid">'+cards+'</div>','/guides/'))
write(Path('about/index.html'),page('About','Learn about the independent Party With Celebs editorial publication.','<article class="article"><h1>About Party With Celebs</h1><p>PartyWithCelebs.com is an independent editorial destination for nightlife and VIP experience planning. Our goal is to publish practical, verifiable guides—not rumors or promises of celebrity access.</p><p>We do not represent celebrities or event organizers. Always confirm event details with official sources.</p></article>','/about/'))
write(Path('contact/index.html'),page('Contact & Business Inquiries','Contact Party With Celebs for editorial, sponsorship and acquisition inquiries.','<article class="article"><h1>Contact & Business Inquiries</h1><p>For editorial corrections, partnerships, advertising, and domain acquisition inquiries, please use the contact email below once it has been activated.</p><p><strong>Email:</strong> hello@partywithcelebs.com</p><p class="notice">Before launch, configure this mailbox in your email provider. This page does not collect form submissions.</p></article>','/contact/'))
write(Path('privacy/index.html'),page('Privacy Policy','Privacy practices for PartyWithCelebs.com.','<article class="article"><h1>Privacy Policy</h1><p>Last updated: '+date.today().isoformat()+'''</p><p>This starter website does not itself operate user accounts, collect newsletter signups, or place advertising cookies. The hosting provider may process basic technical request data such as IP addresses for site delivery and security.</p><p>If analytics, advertising, email subscriptions, or embedded services are added, this policy must be updated to describe those providers, data uses, retention, and visitor choices before activation.</p><p>For privacy inquiries, contact hello@partywithcelebs.com once that mailbox is active.</p><p class="notice">Starter policy for review; adapt to actual services and applicable law before monetization.</p></article>''','/privacy/'))
paths=['/','/guides/','/about/','/contact/','/privacy/']+[f'/guides/{slug}/' for slug,_ in articles]
write(Path('sitemap.xml'),'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+''.join(f'<url><loc>{BASE}{p}</loc></url>' for p in paths)+'</urlset>')
write(Path('robots.txt'),f'User-agent: *\nAllow: /\nSitemap: {BASE}/sitemap.xml\n')
print(f'Built {len(articles)} articles and {len(paths)} pages into {OUT}')
