# PartyWithCelebs.com — Publishing System

A working, dependency-free static publishing system for Cloudflare Pages. Articles live in `content/*.md`; `build.py` converts them into SEO-friendly HTML pages with a sitemap and robots.txt.

## Preview locally

1. Install Python 3 if needed.
2. In this folder run `python3 build.py`.
3. Run `python3 -m http.server 8000 -d public`.
4. Open `http://localhost:8000`.

## Publish an article

1. Create a new file in `content/` with a lowercase hyphenated name, such as `miami-vip-guide.md`.
2. Use the metadata block at the top of an existing article: `title`, `description`, `date` (YYYY-MM-DD), and `category`, followed by a line containing `---`.
3. Write paragraphs and headings (`##`, `###`), bullet lists (`-`), bold (`**...**`) and external links (`[text](https://...)`). Other Markdown features are not supported by this lightweight parser.
4. Commit the file to the GitHub repository's main branch. Cloudflare Pages will automatically rebuild and publish.
5. Confirm the new page and `/sitemap.xml` appear after deployment.

## Deploy with GitHub + Cloudflare Pages

1. Create a **private or public GitHub repository** named `partywithcelebs`. Upload the *contents* of this folder to its root. Do not upload the ZIP as one file.
2. Create a Cloudflare account. In **Workers & Pages**, create a **Pages** project and connect the GitHub repository. Cloudflare UI wording may vary.
3. Select the production branch `main`, framework preset `None`, build command `python3 build.py`, output directory `public` (no leading slash). Set `PYTHON_VERSION` to `3.11` if the build environment needs an explicit version.
4. Deploy and test the assigned `*.pages.dev` preview URL.
5. In the Pages project's **Custom domains**, add `partywithcelebs.com`. Follow Cloudflare's exact DNS instructions. For an apex/root domain, Cloudflare may require moving the domain's authoritative nameservers from GoDaddy to Cloudflare. **Do not delete existing MX, TXT, or other DNS records**; copy and verify them before switching nameservers. The domain remains registered at GoDaddy.
6. Add `www.partywithcelebs.com` and configure one canonical hostname with a redirect from the other. The generated canonical URLs use `https://partywithcelebs.com`.
7. Verify HTTPS works and add the site to Google Search Console. Submit `https://partywithcelebs.com/sitemap.xml`.

## Important before monetization

- Activate `hello@partywithcelebs.com` with your preferred email provider; it is currently just a displayed address.
- Review the privacy policy and add cookie consent/data disclosures if you enable analytics or ad tracking. Check relevant privacy requirements for your audience.
- Do not publish copyrighted celebrity images or imply celebrity endorsement without rights.
- Only publish verifiable event information, with official sources and a clear updated date.
- Add affiliate disclosures near affiliate links and a dedicated advertising policy before running paid placements.
- No newsletter signup is enabled. Connect a consent-based email platform before collecting email addresses.
- This system uses GitHub's web editor as its initial publishing interface; there is no separate admin login or WYSIWYG CMS yet.

## Future upgrades

Add a visual editor, newsletter service, approved affiliate placements, analytics, structured data, and editorial workflow once the site is live. Keep production credentials in Cloudflare/GitHub secrets rather than committing them to the repository.
